
 /**
 * \著作权 Copyright (C), 2016-2020, LZRobot
 * @名称：  Kenblock_hmi_hd.h
 * @作者：  Kenblock
 * @版本：  V0.1.0
 * @时间：  2018/08/1
 * @描述：  使用硬件串口，将串口液晶模块指令整合为库。Kenblock_hmi_hd.cpp 的头文件。
 *
 * \说明
 * 			修改或操控串口液晶的显示数据及内容
 *			注：ArduinoIDE为UTF-8文字编码，而串口液晶模块支持GB2312 BIG5 中文都不能和UTF-8很好的转换，因此在Arduino中仅支持输入英文字符串
 *				推荐在使用USART HMI页面设计时就将固定中文文本设定好，在单片机控制时不再修改
 * \方法列表
 * 
 * 		1. void KenHmiHd::begin(void)
 * 		2. void KenHmiHd::SetFormat(uint8_t *index,uint8_t xcn,uint8_t ycn); 		//设置各种显示框的对齐方式
 * 		3. void KenHmiHd::PrintTxtStr(uint8_t *index,uint8_t *str);  				//设置文本框显示的文字（t0、t1....）
 *		4. void KenHmiHd::PrintNum(uint8_t *index,int num);      					//设置数据框显示的数字（n0、n1....）
 *		5. void KenHmiHd::PrintPGbar(uint8_t *index,uint8_t num);      				//设置进度条的进度0-100(j0、j1....)
 *		6. void KenHmiHd::PrintQRcode(uint8_t *index,uint8_t *str);      			//设置二维码的信息（qr0,qr1...）
 *		7. void KenHmiHd::SetScrollBarFormat(uint8_t *index,uint8_t dir,uint8_t speed,uint8_t gap);   //设置滚动的文字（g0,g1...）方向（0-4）、滚动周期（80-65535）ms、滚动幅度（2-50）像素
 *		8. void KenHmiHd::PrintScrollBar(uint8_t *index,uint8_t *str);             	//设置滚动文本
 *		9. void KenHmiHd::void Page(uint8_t id);             						//更换或刷新某个页面
 *		10.void KenHmiHd::void SetCurveChColor(uint8_t *index,uint8_t ch,uint8_t *color); 				//设置某个通道曲线的颜色
 *		11.void KenHmiHd::PrintCurveCh(uint8_t *index,uint8_t id,uint8_t ch,uint8_t data);   	//某个通道绘制曲线
 *		12.void KenHmiHd::ClearCurveCh(uint8_t *index,uint8_t id,uint8_t ch);   				//清除某个通道绘制的曲线
 * \修订历史
 * `<Author>`      `<Time>`        `<Version>`        `<Descr>`
 *  RJK            2018/08/01      	  0.1.0           新建库文件。
 *  
 * \示例
 *  
 * 		1.HMITEST.ino
 */
#ifndef __Kenblock_hmi_hd_h
#define __Kenblock_hmi_hd_h

#include <Arduino.h>
#include "string.h"

class KenHmiHd
{
	public:
	/**
	* \函数：KenHmiHd
	* \说明：替代KenHmiHd
	* \输入参数：Serial 硬件串口
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	KenHmiHd(HardwareSerial &uart);
	/**
	* \函数：begin
	* \说明：开启串口
	* \输入参数：无
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void begin(void);
	/**
	* \函数：SetFormat
	* \说明：设置各种显示框的对齐方式 如文本框，数字框
	* \输入参数：*index：显示框名字的字符串 如文本框默认为t0 则输入"t0",具体在USART HMI软件中确认
	* \          xcn: 0-水平靠左 1-水平居中 2-水平靠右
	* \			 ycn: 0-垂直靠左 1-垂直居中 2-垂直靠右
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/	
	void SetFormat(uint8_t *index,uint8_t xcn,uint8_t ycn);
	/**
	* \函数：PrintTxtStr
	* \说明：设置文本框显示的字符串，Arduino IDE中仅支持英文
	* \输入参数：*index：显示框名字的字符串 如文本框默认为t0 则输入"t0",具体在USART HMI软件中确认
	* \          *str ：显示的文本的字符串如 "Kenblock"
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/	
	void PrintTxtStr(uint8_t *index,uint8_t *str);  
	/**
	* \函数：PrintNum
	* \说明：设置数字框中显示的数据
	* \输入参数：*index：显示框名字的字符串 如数字框默认为n0 则输入"n0",具体在USART HMI软件中确认
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/	
	void PrintNum(uint8_t *index,int num);
	/**
	* \函数：PrintPGbar
	* \说明：设置进度条的值
	* \输入参数：*index：进度条名字的字符串 如进度条默认为j0 则输入"j0",具体在USART HMI软件中确认
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void PrintPGbar(uint8_t *index,uint8_t num); 
	/**
	* \函数：PrintQRcode
	* \说明：设置二维码的信息
	* \输入参数：*index：二维码名字的字符串 如进度条默认为qr0 则输入"qr0",具体在USART HMI软件中确认
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void PrintQRcode(uint8_t *index,uint8_t *str);
	/**
	* \函数：SetScrollBarFormat
	* \说明：设置滚动文本框的格式，并设置其方向，滚动周期，滚动的单位像素
	* \输入参数：*index：滚动条名字的字符串 如进度条默认为g0 则输入"g0",具体在USART HMI软件中确认
	*\			 dir: 方向 0-从左往右 1-从右往左 2-从上往下 3-从下往上
	*\			 speed：滚动周期80-65535ms
	*\			 gap：滚动幅度2-50像素点
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void SetScrollBarFormat(uint8_t *index,uint8_t dir,uint8_t speed,uint8_t gap); 
	/**
	* \函数：PrintScrollBar
	* \说明：设置滚动文本框的字符串
	* \输入参数：*index：滚动条名字的字符串 如进度条默认为g0 则输入"g0",具体在USART HMI软件中确认
	* \			  *str:文本字符串如："Kenblock"
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void PrintScrollBar(uint8_t *index,uint8_t *str);             //设置滚动文本
	/**
	* \函数：Page
	* \说明：刷新某一个页面或者切换另一个页面
	* \输入参数： id: 页面的ID号，如过有两个画面则ID默认为0和1,具体在USART HMI软件中确认
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void Page(uint8_t id);             //更换或刷新某个页面	
	//曲线相关
	//void SetCurveCh(uint8_t *index,uint8_t num); 			//设置曲线图形的通道数 不支持指令修改
	//void SetCurveDir(uint8_t *index,uint8_t dir); 			//设置曲线运行方向 不支持指令修改
	
	/**
	* \函数：SetCurveChColor
	* \说明：更改某个通道曲线的颜色，支持颜色请看开头注释
	* \输入参数： *index：图表名字的字符串，如默认为s0，则输入"s0"，具体在USART HMI软件中确认
	* \			  ch: 图表中的某一个通道曲线
	* \			  *color：颜色的字符串，如红色"RED",蓝色"BLUE"
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void SetCurveChColor(uint8_t *index,uint8_t ch,uint8_t *color); 	//设置某个通道曲线的颜色
	/**
	* \函数：PrintCurveCh
	* \说明：绘制某个通道的曲线数据
	* \输入参数： id: 图表的ID号，如过有两个图表则ID默认为1和2,具体在USART HMI软件中确认
	* \			  ch: 图表中的某一个通道曲线
	* \			  data：绘制的曲线数据
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void PrintCurveCh(uint8_t id,uint8_t ch,uint8_t data);   //某个通道绘制曲线
	/**
	* \函数：ClearCurveCh
	* \说明：清除某个通道的曲线数据
	* \输入参数： id: 图表的ID号，如过有两个图表则ID默认为1和2,具体在USART HMI软件中确认
	* \			  ch: 图表中的某一个通道曲线
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void ClearCurveCh(uint8_t id,uint8_t ch);   		//清除某个通道绘制的曲线	
	private:
	
	HardwareSerial *m_puart;
};
#endif