
 /**
 * \著作权 Copyright (C), 2016-2020, LZRobot
 * @名称：  Kenblock_mpu6050kalman.h
 * @作者：  Kenblock
 * @版本：  V0.1.0
 * @时间：  2018/06/21
 * @描述：  将MPU6050库整合为卡尔曼滤波库以方便使用，并在平台编程时使用简单化。Kenblock_mpu6050kalman.cpp 的头文件。
 *
 * \说明
 * 			MPU6050获取6轴原始数据，获取3坐标旋转角度。，注意！他使用了IIC-INT接口
 *
 * \方法列表
 * 
 * 		1. void KenKalman::Init(void)
 * 		2. void KenKalman::GetPitchYawRoll(float *data)
 * 		3. void KenKalman::Get6DOFData(int16_t *data)
 *
 * \修订历史
 * `<Author>`      `<Time>`        `<Version>`        `<Descr>`
 *  RJK            2018/06/21      	  0.1.0           新建库文件。
 *  
 * \示例
 *  
 * 		1.kalman.ino
 */
#ifndef __KENBLOCK_MPU6050KALMAN_H
#define __KENBLOCK_MPU6050KALMAN_H

#include "Arduino.h"

/**
 * Class: KenKalman
 * \说明：Class KenKalman 的声明
 */

class KenKalman
{
	public:
	/**
	* \函数：Init
	* \说明：初始化，IIC初始化 MPU6050初始化 kalman参数初始化
	* \输入参数：无
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void Init(void);
	/**
	* \函数：GetPitchYawRoll
	* \说明：获取浮点数的卡尔曼滤波的欧拉角
	* \输入参数：float *data，数据类型为float且长度为3的数组的首地址
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/	
	void GetPitchYawRoll(float *data);
	/**
	* \函数：Get6DOFData
	* \说明：获取int16_t 数据类型的6轴原始数据
	* \输入参数：int16_t *data，数据类型为int16_t且长度为6的数组的首地址
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
	void Get6DOFData(int16_t *data);	
};


#endif